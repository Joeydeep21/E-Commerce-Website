const { Sequelize, DataTypes } = require('sequelize');
require('dotenv').config();

const sequelize = new Sequelize(
  process.env.DB_NAME || 'online_shopping',
  process.env.DB_USER || 'root',
  process.env.DB_PASS || 'root123',
  {
    host: process.env.DB_HOST || 'localhost',
    dialect: 'mysql',
    logging: false
  }
);

// ==================== MODELS ====================
const User = sequelize.define('User', {
  name: DataTypes.STRING,
  email: { type: DataTypes.STRING, unique: true },
  password: DataTypes.STRING,
  role: DataTypes.STRING
}, { tableName: 'users', timestamps: true });

const Category = sequelize.define('Category', {
  name: DataTypes.STRING
}, { tableName: 'categories', timestamps: true });

const Product = sequelize.define('Product', {
  name: DataTypes.STRING,
  description: DataTypes.STRING,
  price: DataTypes.FLOAT,
  stock: DataTypes.INTEGER,
  imageUrl: DataTypes.STRING
}, { tableName: 'products', timestamps: true });

const Cart = sequelize.define('Cart', {}, { tableName: 'carts', timestamps: true });

const CartItem = sequelize.define('CartItem', {
  quantity: { type: DataTypes.INTEGER, defaultValue: 1 }
}, { tableName: 'cart_items', timestamps: true });

const Order = sequelize.define('Order', {
  status: { type: DataTypes.STRING, defaultValue: 'PENDING' },
  total: { type: DataTypes.FLOAT, defaultValue: 0 }
}, { tableName: 'orders', timestamps: true });

const OrderItem = sequelize.define('OrderItem', {
  quantity: { type: DataTypes.INTEGER, defaultValue: 1 }
}, { tableName: 'order_items', timestamps: true });

// ==================== ASSOCIATIONS ====================

// User → Cart (1:1)
User.hasOne(Cart, { onDelete: 'CASCADE' });
Cart.belongsTo(User);

// Category → Products (1:M)
Category.hasMany(Product, { onDelete: 'CASCADE' });
Product.belongsTo(Category);

// Cart ↔ Products (M:N) via CartItem
Cart.belongsToMany(Product, { through: CartItem });
Product.belongsToMany(Cart, { through: CartItem });

// User → Orders (1:M)
User.hasMany(Order, { onDelete: 'CASCADE' });
Order.belongsTo(User);

// Order ↔ Products (M:N) via OrderItem
Order.belongsToMany(Product, { through: OrderItem });
Product.belongsToMany(Order, { through: OrderItem });

// ==================== EXPORT ====================
module.exports = {
  sequelize,
  User,
  Category,
  Product,
  Cart,
  CartItem,
  Order,
  OrderItem
};
