const { User, Category, Product } = require('../config/db');

async function seedData() {
  try {
    // ✅ Seed admin user
    const admin = await User.findOne({ where: { email: 'admin@gmail.com' } });
    if (!admin) {
      await User.create({
        name: 'Admin',
        email: 'admin@gmail.com',
        password: 'admin123', // plain text as requested
        role: 'ADMIN',
      });
      console.log('✅ Admin user created');
    }

    // ✅ Seed categories
    const categories = ['Electronics', 'Fashion', 'Home Appliances'];
    for (const name of categories) {
      const exists = await Category.findOne({ where: { name } });
      if (!exists) {
        await Category.create({ name });
        console.log(`✅ Category ${name} created`);
      }
    }

    // ✅ Get categories
    const electronics = await Category.findOne({ where: { name: 'Electronics' } });
    const fashion = await Category.findOne({ where: { name: 'Fashion' } });

    // ✅ Seed sample products
    if (electronics) {
      const phone = await Product.findOne({ where: { name: 'Smartphone' } });
      if (!phone) {
        await Product.create({
          name: 'Smartphone',
          description: 'Latest smartphone with 5G',
          price: 699.99,
          stock: 50,
          CategoryId: electronics.id,   // ✅ FIXED: capitalized FK
          imageUrl: null,
        });
        console.log('✅ Sample product Smartphone created');
      }
    }

    if (fashion) {
      const tshirt = await Product.findOne({ where: { name: 'T-Shirt' } });
      if (!tshirt) {
        await Product.create({
          name: 'T-Shirt',
          description: 'Comfortable cotton t-shirt',
          price: 19.99,
          stock: 100,
          CategoryId: fashion.id,   // ✅ FIXED: capitalized FK
          imageUrl: null,
        });
        console.log('✅ Sample product T-Shirt created');
      }
    }

  } catch (err) {
    console.error('❌ Seed data failed:', err);
  }
}

module.exports = { seedData };
