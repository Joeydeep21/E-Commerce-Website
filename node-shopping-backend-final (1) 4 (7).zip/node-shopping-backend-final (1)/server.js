const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
require('dotenv').config();
const { sequelize } = require('./config/db');
const { requestInterceptor } = require('./middleware/requestInterceptor');
const { errorHandler } = require('./middleware/errorHandler');
const { seedData } = require('./seed/seedData');

// Routes
const userRoutes = require('./routes/userRoutes');
const productRoutes = require('./routes/productRoutes');
const categoryRoutes = require('./routes/categoryRoutes');
const cartRoutes = require('./routes/cartRoutes');
const orderRoutes = require('./routes/orderRoutes');

// Swagger
const swaggerUi = require('swagger-ui-express');
const swaggerSpec = require('./swagger/swaggerDocs');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// ✅ Enable CORS for React frontend (http://localhost:3000)
// app.use(cors({
//   origin: "http://localhost:3000",
//   methods: ["GET", "POST", "PUT", "DELETE"],
//   allowedHeaders: ["Content-Type", "Authorization"]
// }));

// Serve static images
app.use('/uploads', express.static('E:/Ecommerce Project - FullStack Project/images'));

// Interceptor
app.use(requestInterceptor);

// API routes
app.use('/api/user', userRoutes);
app.use('/api/category', categoryRoutes);
app.use('/api/product', productRoutes);
app.use('/api/user', cartRoutes);  
app.use('/api/user', orderRoutes)

// Swagger docs
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));

// Error handler
app.use(errorHandler);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Database sync + seed + server start
sequelize.sync({ alter: true }).then(async () => {
  await seedData();
  app.listen(8080, () => {
    console.log('Server running on port 8080');
  });
}).catch((err) => {
  console.error("Database connection failed:", err);
});









