// file: validators/userDto.js
// Joi validation schemas for user registration and login

const Joi = require('joi');

// Registration schema matching frontend AddUserForm fields
const addUserSchema = Joi.object({
  firstName: Joi.string().min(1).required(),
  lastName: Joi.string().allow('', null),
  emailId: Joi.string().email().required(),
  password: Joi.string().min(3).required(),
  phoneNo: Joi.string().pattern(/^[0-9]+$/).min(6).max(15).required(),
  street: Joi.string().allow('', null),
  city: Joi.string().allow('', null),
  pincode: Joi.alternatives().try(Joi.number().integer(), Joi.string()).allow('', null),
  role: Joi.string().valid('Admin', 'Delivery', 'Customer').required()
});

// Login schema expected by frontend (uses emailId + password)
const loginSchema = Joi.object({
  emailId: Joi.string().email().required(),
  password: Joi.string().required(),
  role: Joi.string().valid('Admin', 'Delivery', 'Customer').optional()
});

// Simple middleware factory to validate req.body against a schema
const validate = (schema) => (req, res, next) => {
  const { error, value } = schema.validate(req.body, { abortEarly: false, stripUnknown: true });
  if (error) {
    // Return plain error messages (one concatenated string like Spring @Valid behavior)
    const message = error.details.map(d => d.message).join('; ');
    return res.status(400).json({ success: false, responseMessage: message });
  }
  req.body = value; // sanitized
  next();
};

module.exports = { addUserSchema, loginSchema, validate };
