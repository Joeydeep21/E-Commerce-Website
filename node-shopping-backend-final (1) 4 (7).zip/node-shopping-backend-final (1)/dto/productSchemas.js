// dto/productSchemas.js
const Joi = require('joi');

// Build schema and accept frontend keys 'title' and 'quantity' by renaming them to 'name' and 'stock'.
// Also enable conversion so numeric strings convert to numbers.
const productAddSchema = Joi.object({
  name: Joi.string().required(),
  description: Joi.string().allow('', null),
  price: Joi.number().positive().required(),
  stock: Joi.number().integer().min(0).default(0),
  categoryId: Joi.number().integer().required()
})
// Allow frontend to send `title` instead of `name`, or `quantity` instead of `stock`
// rename returns a new object with keys renamed; using options to ignore undefined and allow override.
.rename('title', 'name', { override: true, ignoreUndefined: true })
.rename('quantity', 'stock', { override: true, ignoreUndefined: true })
.preferences({ convert: true }); // convert string numbers to numbers

module.exports = { productAddSchema };
