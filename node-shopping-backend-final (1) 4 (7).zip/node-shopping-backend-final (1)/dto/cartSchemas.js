const Joi = require('joi');

const addToCartSchema = Joi.object({
  userId: Joi.number().integer().required(),
  productId: Joi.number().integer().required(),
  quantity: Joi.number().integer().min(1).default(1),
});

module.exports = { addToCartSchema };
