const Joi = require('joi');

const updateDeliveryStatusSchema = Joi.object({
  orderId: Joi.number().integer().required(),
  status: Joi.string().valid('PENDING', 'SHIPPED', 'DELIVERED').required(),
});

module.exports = { updateDeliveryStatusSchema };
