module.exports = (sequelize, DataTypes) => {
  const CartProduct = sequelize.define('CartProduct', {
    quantity: { type: DataTypes.INTEGER, defaultValue: 1 }
  }, { timestamps: true });

  return CartProduct;
};
