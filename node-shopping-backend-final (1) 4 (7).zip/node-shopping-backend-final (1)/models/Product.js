// models/Product.js
module.exports = (sequelize, DataTypes) => {
  const Product = sequelize.define('Product', {
    id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },

    // persisted column for name/title
    name: { type: DataTypes.STRING, allowNull: false },

    description: { type: DataTypes.TEXT },

    // price stored as decimal
    price: { type: DataTypes.DECIMAL(10, 2), allowNull: false },

    // persisted stock column (backend canonical)
    stock: { type: DataTypes.INTEGER, defaultValue: 0 },

    // expose a readable/writable virtual alias 'quantity' for frontend compatibility
    quantity: {
      type: DataTypes.VIRTUAL,
      get() {
        // return stock when reading product.quantity
        return this.getDataValue('stock');
      },
      set(value) {
        // when code assigns product.quantity = x, write into stock
        this.setDataValue('stock', value);
      }
    },

    imageUrl: { type: DataTypes.STRING }
  }, {
    timestamps: true,
    tableName: 'products' // keep same table name if used elsewhere
  });

  return Product;
};
