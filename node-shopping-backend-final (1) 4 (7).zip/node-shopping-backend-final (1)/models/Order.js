module.exports = (sequelize, DataTypes) => {
  const Order = sequelize.define('Order', {
    id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
    status: { type: DataTypes.STRING, defaultValue: 'PENDING' },
    total: { type: DataTypes.DECIMAL(10, 2), defaultValue: 0.0 }
  }, { timestamps: true });

  return Order;
};
