const express = require('express');
const { createCategory, getCategories } = require('../controllers/categoryController');

const router = express.Router();

// /api/category/add
router.post('/add', createCategory);

// /api/category/all
router.get('/all', getCategories);

module.exports = router;
