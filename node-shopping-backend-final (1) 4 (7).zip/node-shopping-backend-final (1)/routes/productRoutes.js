const express = require('express');
const { addProduct, getAllProducts, getProductById, getProductsByCategory, serveImage } = require('../controllers/productController');
const { productAddSchema } = require('../dto/productSchemas');
const { validate } = require('../middleware/validate');
const upload = require('../config/multer'); // multer config

const router = express.Router();

// /api/product/add
router.post('/add', upload.single('image'), validate(productAddSchema), addProduct);

// /api/product/all
router.get('/all', getAllProducts);

// /api/product/id?productId=...
router.get('/id', getProductById);

// /api/product/category?categoryId=...
router.get('/category', getProductsByCategory);

// /api/product/{imageName} -> serve image
router.get('/:imageName', serveImage);

module.exports = router;
