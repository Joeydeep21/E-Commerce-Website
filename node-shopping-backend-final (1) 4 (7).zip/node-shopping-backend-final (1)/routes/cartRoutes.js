const express = require('express');
const router = express.Router();
const { addToCart, removeFromCart, getMyCart } = require('../controllers/cartController');

// Add to cart (frontend uses POST /cart/add with body)
router.post('/cart/add', addToCart);

// Remove from cart (frontend uses GET /mycart/remove?cartId=...)
router.get('/mycart/remove', removeFromCart);

// Get my cart (frontend uses GET /mycart?userId=...)
router.get('/mycart', getMyCart);

module.exports = router;
