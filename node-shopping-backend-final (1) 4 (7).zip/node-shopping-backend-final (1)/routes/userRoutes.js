const express = require('express');
const { registerUser, loginUser, forgetPassword, getAllOrders, getOrderById, assignDelivery, getAllDeliveryPersons, placeOrder, getMyOrders } = require('../controllers/userController.js')
const { addUserSchema, loginSchema } = require('../dto/userSchemas');
const { validate } = require('../middleware/validate');

const router = express.Router();

/**
 * @swagger
 * tags:
 *   name: Users
 *   description: User management APIs
 */

/**
 * @swagger
 * /api/users/register:
 *   post:
 *     summary: Register a new user
 *     tags: [Users]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name: { type: string, example: "John Doe" }
 *               email: { type: string, example: "john@example.com" }
 *               password: { type: string, example: "password123" }
 *     responses:
 *       200:
 *         description: User registered successfully
 */
router.post('/register', validate(addUserSchema), registerUser);

// My Orders (Customer)
router.get('/myorder', getMyOrders);


/**
 * @swagger
 * /api/users/login:
 *   post:
 *     summary: Login user
 *     tags: [Users]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               email: { type: string, example: "john@example.com" }
 *               password: { type: string, example: "password123" }
 *     responses:
 *       200:
 *         description: User logged in successfully
 */
router.post('/login', validate(loginSchema), loginUser);

/**
 * @swagger
 * /api/users:
 *   get:
 *     summary: Get all users
 *     tags: [Users]
 *     responses:
 *       200:
 *         description: List of users
 */
// router.get('/', getAllUsers);

// /api/user/admin/login
// router.post('/admin/login', adminLogin);

// /api/user/deliveryperson/login
// router.post('/deliveryperson/login', deliveryPersonLogin);

// /api/user/deliveryperson/register
// router.post('/deliveryperson/register', registerDeliveryPerson);

// /api/user/forget-password
router.post('/forget-password', forgetPassword);

// /api/user/admin/allorder
router.get('/admin/allorder', getAllOrders);

// /api/user/admin/showorder?orderId=...
router.get('/admin/showorder', getOrderById);

// /api/user/admin/order/assignDelivery
router.post('/admin/order/assignDelivery', assignDelivery);

// /api/user/deliveryperson/all
router.get('/deliveryperson/all', getAllDeliveryPersons);

// /api/user/order?userId=...
router.post('/order', placeOrder);

module.exports = router;
