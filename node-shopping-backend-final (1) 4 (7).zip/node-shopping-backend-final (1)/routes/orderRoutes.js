const express = require('express');
const { placeOrder, getUserOrders } = require('../controllers/orderController');

const router = express.Router();

/**
 * @swagger
 * tags:
 *   name: Orders
 *   description: Order management APIs
 */

/**
 * @swagger
 * /api/orders:
 *   post:
 *     summary: Place a new order
 *     tags: [Orders]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               userId: { type: integer, example: 1 }
 *               products:
 *                 type: array
 *                 items:
 *                   type: object
 *                   properties:
 *                     productId: { type: integer, example: 2 }
 *                     quantity: { type: integer, example: 1 }
 *                     price: { type: number, example: 19.99 }
 *     responses:
 *       200:
 *         description: Order placed successfully
 */
router.post('/order', placeOrder);

/**
 * @swagger
 * /api/orders/{userId}:
 *   get:
 *     summary: Get orders for a user
 *     tags: [Orders]
 *     parameters:
 *       - in: path
 *         name: userId
 *         schema: { type: integer }
 *         required: true
 *     responses:
 *       200:
 *         description: List of user's orders
 */
router.get('order/:userId', getUserOrders);

module.exports = router;
