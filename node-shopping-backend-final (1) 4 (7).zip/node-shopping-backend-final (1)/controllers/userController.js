const { User, Order, Product, Cart, Category } = require('../config/db');

// ✅ helper: normalize role
const normalizeRole = (role) => {
  if (!role) return "Customer";
  const lower = role.toLowerCase();
  if (lower === "admin") return "Admin";
  if (lower.startsWith("delivery")) return "Delivery";
  return "Customer";
};

// ✅ helper: map product into frontend shape
const mapProduct = (product) => ({
  id: product.id,
  title: product.name,
  description: product.description,
  price: product.price,
  quantity: product.stock,
  imageName: product.imageUrl || "default.png",
  category: product.Category ? {
    id: product.Category.id,
    title: product.Category.name
  } : { id: 0, title: "Uncategorized" }
});

// // ✅ Register User
// const registerUser = async (req, res, next) => {
//   try {
//     const { name, email, emailId, password, role } = req.body;
//     const finalEmail = email || emailId;

//     const existing = await User.findOne({ where: { email: finalEmail } });
//     if (existing) {
//       return res.status(400).json({
//         success: false,
//         responseMessage: "User already exists"
//       });
//     }

//     const normalizedRole = normalizeRole(role);

//     const user = await User.create({
//       name,
//       email: finalEmail,
//       password,
//       role: normalizedRole
//     });
//     console.log("userrrr",user);
    

//     res.json({
//       success: true,
//       responseMessage: "User registered successfully",
//       users: [user]
//     });
//   } catch (err) {
//     next(err);
//   }
// };

// // ✅ Login User
// const loginUser = async (req, res, next) => {
//   try {
//     const { email, emailId, password } = req.body;
//     const finalEmail = email || emailId;

//     const user = await User.findOne({ where: { email: finalEmail, password } });
//     if (!user) {
//       return res.status(401).json({
//         success: false,
//         responseMessage: "Invalid credentials"
//       });
//     }

//     const normalizedUser = {
//       ...user.toJSON(),
//       role: normalizeRole(user.role)
//     };

//     res.json({
//       success: true,
//       responseMessage: "Login successful",
//       users: [normalizedUser]
//     });
//   } catch (err) {
//     next(err);
//   }
// };

// // ✅ Admin Login
// const adminLogin = async (req, res, next) => {
//   try {
//     const { emailId, password } = req.body;
//     const user = await User.findOne({ where: { email: emailId, password, role: "Admin" } });

//     if (!user) {
//       return res.status(401).json({ success: false, responseMessage: "Invalid admin credentials" });
//     }

//     res.json({ success: true, responseMessage: "Admin login successful", users: [user] });
//   } catch (err) {
//     next(err);
//   }
// };

// // ✅ Delivery Person Login
// const deliveryPersonLogin = async (req, res, next) => {
//   try {
//     console.log("ssspspflslofslpgmsdklmgklfmglx lb cvmbl dkmb nknsld bkmd ,bms");
    
//     const { emailId, password } = req.body;

//     // check with role = DELIVERY (uppercase, matches DB)
//     const user = await User.findOne({
//       where: { email: emailId, password, role: "DELIVERY" }
//     });
//     console.log("user----",user);
    

//     if (!user) {
//       return res.status(401).json({
//         success: false,
//         responseMessage: "Invalid delivery credentials"
//       });
//     }

//     res.json({
//       success: true,
//       responseMessage: "Delivery person login successful",
//       users: [user]
//     });
//   } catch (err) {
//     next(err);
//   }
// };


// // ✅ Register Delivery Person
// const registerDeliveryPerson = async (req, res, next) => {
//   try {
//     const { name, emailId, password } = req.body;

//     const existing = await User.findOne({ where: { email: emailId } });
//     if (existing) {
//       return res.status(400).json({ success: false, responseMessage: "Delivery person already exists" });
//     }

//     const user = await User.create({ name, email: emailId, password, role: "Delivery" });
//     res.json({ success: true, responseMessage: "Delivery person registered successfully", users: [user] });
//   } catch (err) {
//     next(err);
//   }
// };

//new api register
const registerUser = async (req, res, next) => {
  try {
    // Accept both possible field names
    const {
      firstName,
      lastName,
      name,
      email,
      emailId,
      password,
      role,
      phoneNo,
      street,
      city,
      pincode
    } = req.body;

    const finalEmail = email || emailId;
    if (!finalEmail || !password) {
      return res.status(400).json({ success: false, responseMessage: "Email and password are required" });
    }

    // Build name from firstName + lastName if available, else use name
    const fullName = (firstName || lastName) ? `${firstName || ''} ${lastName || ''}`.trim() : (name || null);

    // Check existing user
    const existing = await User.findOne({ where: { email: finalEmail } });
    if (existing) {
      return res.status(400).json({ success: false, responseMessage: "User already exists" });
    }

    const normalizedRole = normalizeRole(role);

    // Create user - store commonly used fields; you can expand per your model
    const user = await User.create({
      name: fullName || `User-${Date.now()}`,
      email: finalEmail,
      password,
      role: normalizedRole,
      phoneNo: phoneNo || null,
      street: street || null,
      city: city || null,
      pincode: pincode || null
    });

    // Return created user with normalized role (friendly casing)
    const returned = { ...user.toJSON(), role: normalizedRole };

    res.json({
      success: true,
      responseMessage: "User registered successfully",
      users: [returned]
    });
  } catch (err) {
    next(err);
  }
};

//new api login
const loginUser = async (req, res, next) => {
  try {
    const { email, emailId, password, role: requestedRole } = req.body;
    const finalEmail = email || emailId;

    if (!finalEmail || !password) {
      return res.status(400).json({ success: false, responseMessage: "Email and password are required" });
    }

    const user = await User.findOne({ where: { email: finalEmail, password } });
    if (!user) {
      return res.status(401).json({ success: false, responseMessage: "Invalid credentials" });
    }

    // Normalize stored role to friendly casing
    const userRoleNormalized = normalizeRole(user.role);

    // If frontend sent a role, ensure it matches (case-insensitive)
    if (requestedRole) {
      const reqNorm = normalizeRole(requestedRole);
      if (reqNorm !== userRoleNormalized) {
        return res.status(401).json({ success: false, responseMessage: "Invalid credentials" });
      }
    }

    // Return sanitized user object with normalized role
    const returned = { ...user.toJSON(), role: userRoleNormalized };
        res.json({
      success: true,
      responseMessage: "Login successful",
      users: [returned]
    });
  } catch (err) {
    next(err);
  }
};



// ✅ Forget Password
const forgetPassword = async (req, res, next) => {
  try {
    const { emailId, newPassword } = req.body;

    const user = await User.findOne({ where: { email: emailId } });
    if (!user) {
      return res.status(404).json({ success: false, responseMessage: "User not found" });
    }

    user.password = newPassword;
    await user.save();

    res.json({ success: true, responseMessage: "Password updated successfully" });
  } catch (err) {
    next(err);
  }
};

// ✅ Get All Orders (Admin)
// const getAllOrders = async (req, res, next) => {
//   try {
//     const orders = await Order.findAll({ include: [Product, User] });
//     res.json({ success: true, responseMessage: "Orders fetched successfully", orders });
//   } catch (err) {
//     next(err);
//   }
// };
/**
 * Helper: find User-related associations on Order and return their alias names.
 * Returns object: { customerAlias: string|null, deliveryAlias: string|null, allUserAliases: [] }
 */
function detectUserAliasesOnOrder() {
  const assocValues = Object.values(Order.associations || {});
  const userAssocs = assocValues.filter(a => a.target && a.target.name === User.name);

  const allUserAliases = userAssocs.map(a => a.as);

  // Heuristics: pick the alias likely used for the ordering customer (user/customer)
  let customerAlias = null;
  let deliveryAlias = null;

  for (const a of allUserAliases) {
    const lower = String(a).toLowerCase();
    if (!customerAlias && (lower.includes('user') || lower.includes('customer') || lower.includes('owner') )) {
      customerAlias = a;
    }
    if (!deliveryAlias && (lower.includes('delivery') || lower.includes('deliveryperson') || lower.includes('delivery_person') || lower.includes('deliver') )) {
      deliveryAlias = a;
    }
  }

  // fallback: if we didn't detect customerAlias but there's at least one alias, use the first as customer
  if (!customerAlias && allUserAliases.length > 0) {
    customerAlias = allUserAliases[0];
  }

  return { customerAlias, deliveryAlias, allUserAliases };
}

const getAllOrders = async (req, res, next) => {
  try {
    // Detect aliases dynamically
    const { customerAlias, deliveryAlias, allUserAliases } = detectUserAliasesOnOrder();

    // Build includes dynamically:
    const include = [];

    // include Products (make sure association exists)
    if (Order.associations && Order.associations.Products) {
      include.push({ model: Product, include: [Category] });
    } else {
      // attempt to find any association whose target is Product
      const prodAssoc = Object.values(Order.associations || {}).find(a => a.target && a.target.name === Product.name);
      if (prodAssoc) include.push({ model: Product, as: prodAssoc.as, include: [Category] });
    }

    // include customer user association (if found)
    if (customerAlias) {
      include.push({ model: User, as: customerAlias });
    } else {
      // if no alias available, try include without alias (works if Order.belongsTo(User) used without 'as')
      include.push({ model: User });
    }

    // include delivery person association only if an alias clearly exists and is different from customerAlias
    if (deliveryAlias && deliveryAlias !== customerAlias) {
      include.push({ model: User, as: deliveryAlias, required: false });
    } else {
      // if there are multiple user aliases, include the others as non-required (to capture deliveryperson)
      for (const a of allUserAliases) {
        if (a !== customerAlias) include.push({ model: User, as: a, required: false });
      }
    }

    // Fetch orders with the constructed include list
    const orders = await Order.findAll({
      include,
      order: [['createdAt', 'DESC']]
    });

    // Helper to read included user object by alias (safe)
    const readIncludedUser = (orderInstance, alias) => {
      if (!alias) return null;
      return orderInstance[alias] || null;
    };

    const mappedOrders = [];

    orders.forEach(order => {
      // determine customer object
      const customer = (customerAlias && order[customerAlias]) ? order[customerAlias] : (order.User || null);

      // determine delivery person object: pick deliveryAlias if present, else any other included User that is not customer
      let deliveryPerson = null;
      if (deliveryAlias && order[deliveryAlias]) {
        deliveryPerson = order[deliveryAlias];
      } else {
        // search other included user-like properties
        const userAliases = Object.keys(order).filter(k => allUserAliases.includes(k));
        for (const a of userAliases) {
          if (a !== customerAlias && order[a]) {
            deliveryPerson = order[a];
            break;
          }
        }
      }

      // Products may be at order.Products or at alias if association used custom alias.
      const products = order.Products || order.products || [];

      if (Array.isArray(products) && products.length > 0) {
        products.forEach(product => {
          const quantity = (product.OrderItem && product.OrderItem.quantity) ? product.OrderItem.quantity : (product.OrderItem && product.OrderItem.qty) || 1;
          const price = product.price ? parseFloat(product.price) : 0;
          const totalPrice = quantity * price;

          mappedOrders.push({
            orderId: order.id,
            productImage: product.imageUrl || 'default.png',
            productName: product.name || product.title || '',
            productDescription: product.description || '',
            quantity,
            totalPrice,
            userName: (customer && (customer.name || `${customer.firstName || ''} ${customer.lastName || ''}`.trim())) || 'Unknown',
            address: {
              street: (customer && (customer.street || customer.addressStreet)) || '',
              city: (customer && (customer.city || customer.addressCity)) || '',
              pincode: (customer && (customer.pincode || customer.zip || customer.postalCode)) || ''
            },
            userPhone: (customer && (customer.phoneNo || customer.phone || customer.contact)) || '',
            orderDate: order.createdAt || null,
            deliveryDate: order.deliveryDate || order.updatedAt || null,
            deliveryStatus: order.status || order.deliveryStatus || '',
            deliveryPersonName: (deliveryPerson && (deliveryPerson.name || `${deliveryPerson.firstName || ''} ${deliveryPerson.lastName || ''}`.trim())) || 'Not Assigned',
            deliveryPersonContact: (deliveryPerson && (deliveryPerson.phoneNo || deliveryPerson.contact)) || 'N/A'
          });
        });
      } else {
        // no products - still push a row to avoid crash
        mappedOrders.push({
          orderId: order.id,
          productImage: 'default.png',
          productName: '',
          productDescription: '',
          quantity: 0,
          totalPrice: 0,
          userName: (customer && (customer.name || 'Unknown')) || 'Unknown',
          address: {
            street: (customer && customer.street) || '',
            city: (customer && customer.city) || '',
            pincode: (customer && customer.pincode) || ''
          },
          userPhone: (customer && (customer.phoneNo || '')) || '',
          orderDate: order.createdAt || null,
          deliveryDate: order.deliveryDate || order.updatedAt || null,
          deliveryStatus: order.status || '',
          deliveryPersonName: (deliveryPerson && (deliveryPerson.name || 'Not Assigned')) || 'Not Assigned',
          deliveryPersonContact: (deliveryPerson && (deliveryPerson.phoneNo || 'N/A')) || 'N/A'
        });
      }
    });

    return res.json({
      success: true,
      responseMessage: 'Orders fetched successfully',
      orders: mappedOrders
    });
  } catch (err) {
    // If Sequelize complains about include, return useful error instead of crashing
    if (err && err.name && err.name === 'SequelizeEagerLoadingError') {
      return res.status(500).json({ success: false, responseMessage: 'Order associations misconfigured on server', error: err.message });
    }
    next(err);
  }
};


// ✅ Get Order By ID (Admin)
const getOrderById = async (req, res, next) => {
  try {
    const { orderId } = req.query;
    const order = await Order.findByPk(orderId, { include: [Product, User] });

    if (!order) {
      return res.status(404).json({ success: false, responseMessage: "Order not found" });
    }

    res.json({ success: true, responseMessage: "Order found", order });
  } catch (err) {
    next(err);
  }
};

// ✅ Assign Delivery
// const assignDelivery = async (req, res, next) => {
//   try {
//     const { orderId, deliveryPersonId } = req.body;
//     const order = await Order.findByPk(orderId);
//     const deliveryPerson = await User.findByPk(deliveryPersonId);

//     if (!order || !deliveryPerson) {
//       return res.status(404).json({ success: false, responseMessage: "Order or delivery person not found" });
//     }

//     order.deliveryPersonId = deliveryPerson.id;
//     order.status = "ASSIGNED";
//     await order.save();

//     res.json({ success: true, responseMessage: "Delivery person assigned successfully", order });
//   } catch (err) {
//     next(err);
//   }
// };



/** Helper: detect user aliases on Order */
function detectUserAliasesOnOrder() {
  const assocValues = Object.values(Order.associations || {});
  const userAssocs = assocValues.filter(a => a.target && a.target.name === User.name);
  const allUserAliases = userAssocs.map(a => a.as);

  let customerAlias = null;
  let deliveryAlias = null;
  for (const a of allUserAliases) {
    const lower = String(a).toLowerCase();
    if (!customerAlias && (lower.includes('user') || lower.includes('customer') || lower.includes('owner'))) customerAlias = a;
    if (!deliveryAlias && (lower.includes('delivery') || lower.includes('deliveryperson') || lower.includes('deliver'))) deliveryAlias = a;
  }
  if (!customerAlias && allUserAliases.length > 0) customerAlias = allUserAliases[0];
  return { customerAlias, deliveryAlias, allUserAliases };
}

/** Helper: fetch and map orders into frontend expected flattened shape */
async function fetchAndMapOrders() {
  const { customerAlias, deliveryAlias, allUserAliases } = detectUserAliasesOnOrder();

  // Build includes
  const include = [];

  // Products
  if (Order.associations && Order.associations.Products) {
    include.push({ model: Product, include: [Category] });
  } else {
    const prodAssoc = Object.values(Order.associations || {}).find(a => a.target && a.target.name === Product.name);
    if (prodAssoc) include.push({ model: Product, as: prodAssoc.as, include: [Category] });
  }

  // Customer
  if (customerAlias) include.push({ model: User, as: customerAlias });
  else include.push({ model: User });

  // Delivery persons (other user-like aliases)
  if (deliveryAlias && deliveryAlias !== customerAlias) {
    include.push({ model: User, as: deliveryAlias, required: false });
  } else {
    for (const a of allUserAliases) {
      if (a !== customerAlias) include.push({ model: User, as: a, required: false });
    }
  }

  const orders = await Order.findAll({ include, order: [['createdAt', 'DESC']] });

  const mappedOrders = [];

  orders.forEach(order => {
    const customer = (customerAlias && order[customerAlias]) ? order[customerAlias] : (order.User || null);

    // Find delivery person (if any)
    let deliveryPerson = null;
    if (deliveryAlias && order[deliveryAlias]) {
      deliveryPerson = order[deliveryAlias];
    } else {
      for (const a of allUserAliases) {
        if (a !== customerAlias && order[a]) {
          deliveryPerson = order[a];
          break;
        }
      }
    }

    const products = order.Products || order.products || [];

    if (Array.isArray(products) && products.length > 0) {
      products.forEach(product => {
        const quantity = (product.OrderItem && (product.OrderItem.quantity || product.OrderItem.qty)) || 1;
        const price = product.price ? parseFloat(product.price) : 0;
        const totalPrice = quantity * price;

        mappedOrders.push({
          orderId: order.id,
          productImage: product.imageUrl || 'default.png',
          productName: product.name || product.title || '',
          productDescription: product.description || '',
          quantity,
          totalPrice,
          userName: (customer && (customer.name || `${customer.firstName || ''} ${customer.lastName || ''}`.trim())) || 'Unknown',
          address: {
            street: (customer && (customer.street || customer.addressStreet)) || '',
            city: (customer && (customer.city || customer.addressCity)) || '',
            pincode: (customer && (customer.pincode || customer.zip || customer.postalCode)) || ''
          },
          userPhone: (customer && (customer.phoneNo || customer.phone || customer.contact)) || '',
          orderDate: order.createdAt || null,
          deliveryDate: order.deliveryDate || order.updatedAt || null,
          deliveryStatus: order.status || order.deliveryStatus || '',
          deliveryPersonName: (deliveryPerson && (deliveryPerson.name || `${deliveryPerson.firstName || ''} ${deliveryPerson.lastName || ''}`.trim())) || 'Not Assigned',
          deliveryPersonContact: (deliveryPerson && (deliveryPerson.phoneNo || deliveryPerson.contact)) || 'N/A'
        });
      });
    } else {
      mappedOrders.push({
        orderId: order.id,
        productImage: 'default.png',
        productName: '',
        productDescription: '',
        quantity: 0,
        totalPrice: 0,
        userName: (customer && (customer.name || 'Unknown')) || 'Unknown',
        address: {
          street: (customer && customer.street) || '',
          city: (customer && customer.city) || '',
          pincode: (customer && customer.pincode) || ''
        },
        userPhone: (customer && (customer.phoneNo || '')) || '',
        orderDate: order.createdAt || null,
        deliveryDate: order.deliveryDate || order.updatedAt || null,
        deliveryStatus: order.status || '',
        deliveryPersonName: (deliveryPerson && (deliveryPerson.name || 'Not Assigned')) || 'Not Assigned',
        deliveryPersonContact: (deliveryPerson && (deliveryPerson.phoneNo || 'N/A')) || 'N/A'
      });
    }
  });

  return mappedOrders;
}

/** POST /api/user/admin/order/assignDelivery */
const assignDelivery = async (req, res, next) => {
  try {
    const { orderId, deliveryId } = req.body;

    if (!orderId || !deliveryId) {
      return res.status(400).json({ success: false, responseMessage: 'orderId and deliveryId are required', orders: [] });
    }

    const order = await Order.findByPk(orderId);
    if (!order) {
      return res.status(404).json({ success: false, responseMessage: 'Order not found', orders: [] });
    }

    const deliveryUser = await User.findByPk(deliveryId);
    if (!deliveryUser) {
      return res.status(404).json({ success: false, responseMessage: 'Delivery person not found', orders: [] });
    }

    // Try association setter if it exists
    if (typeof order.setDeliveryPerson === 'function') {
      await order.setDeliveryPerson(deliveryUser);
    } else if ('DeliveryPersonId' in order || 'deliveryPersonId' in order || 'deliveryId' in order) {
      if ('DeliveryPersonId' in order) order.DeliveryPersonId = deliveryId;
      else if ('deliveryPersonId' in order) order.deliveryPersonId = deliveryId;
      else order.deliveryId = deliveryId;
      await order.save();
    } else {
      // if there's no FK, try to set a generic field 'deliveryPersonId' anyway
      try {
        order.deliveryPersonId = deliveryId;
        await order.save();
      } catch (e) {
        // ignore — we'll still update status if needed
      }
    }

    // Optionally update order status
    order.status = order.status || order.deliveryStatus || 'ASSIGNED';
    await order.save();

    // Re-fetch and map orders
    const mappedOrders = await fetchAndMapOrders();

    return res.json({
      success: true,
      responseMessage: 'Delivery assigned successfully',
      orders: Array.isArray(mappedOrders) ? mappedOrders : []
    });
  } catch (err) {
    console.error('assignDelivery error:', err);
    return res.status(500).json({
      success: false,
      responseMessage: 'Server error while assigning delivery',
      error: err.message,
      orders: []
    });
  }
};

/**
 * POST /api/user/admin/order/assignDelivery
 * Body: { orderId, deliveryId }
 */



// ✅ Get All Delivery Persons
// const getAllDeliveryPersons = async (req, res, next) => {
//   try {
//     const deliveryPersons = await User.findAll({ where: { role: 'Delivery' } });
//     console.log();
    
//     res.json({ success: true, responseMessage: "Delivery persons fetched successfully", users: deliveryPersons });
//   } catch (err) {
//     next(err);
//   }
// };
const getAllDeliveryPersons = async (req, res, next) => {
  try {
    // Fetch users whose role indicates Delivery (be flexible about casing)
    const deliveryUsers = await User.findAll({
      where: {
        role: ['Delivery', 'DELIVERY', 'delivery'] // Sequelize will work with array only if DB supports; otherwise use Op.in
      },
      order: [['createdAt', 'ASC']]
    });

    // Map / normalize each user to include firstName and lastName for frontend
    const users = deliveryUsers.map(u => {
      const plain = u.toJSON ? u.toJSON() : u;
      const fullName = (plain.name || '').trim();

      let firstName = '';
      let lastName = '';

      if (fullName) {
        const parts = fullName.split(/\s+/);
        firstName = parts.shift() || '';
        lastName = parts.join(' ') || '';
      }

      return {
        ...plain,
        firstName,
        lastName
      };
    });

    return res.json({
      success: true,
      responseMessage: 'Delivery persons fetched successfully',
      users
    });
  } catch (err) {
    next(err);
  }
};

// ✅ Place Order (Customer)
const placeOrder = async (req, res, next) => {
  try {
    const { userId } = req.query;

    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        responseMessage: "User not found"
      });
    }

    // fetch user cart
    const cart = await Cart.findOne({ where: { UserId: userId }, include: [Product] });
    if (!cart || cart.Products.length === 0) {
      return res.status(400).json({
        success: false,
        responseMessage: "Cart is empty"
      });
    }

    // create order
    const order = await Order.create({ UserId: userId, status: "PENDING", total: 0 });
    let total = 0;

    for (const product of cart.Products) {
      const quantity = product.CartItem.quantity;
      const price = product.price;

      total += price * quantity;
      await order.addProduct(product, { through: { quantity, price } });
    }

    order.total = total;
    await order.save();

    // clear cart
    await cart.setProducts([]);

    res.json({
      success: true,
      responseMessage: "Order placed successfully",
      orders: [order]
    });
  } catch (err) {
    next(err);
  }
};

// ✅ Get My Orders (Customer)
const getMyOrders = async (req, res, next) => {
  try {
    const { userId } = req.query;

    if (!userId) {
      return res.status(400).json({
        success: false,
        responseMessage: "UserId is required"
      });
    }

    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        responseMessage: "User not found"
      });
    }

    const orders = await Order.findAll({
      where: { UserId: userId },
      include: [{ model: Product, include: [Category] }]
    });

       // ✅ Flatten orders + products
    const mappedOrders = [];

    orders.forEach(order => {
      order.Products.forEach(product => {
        mappedOrders.push({
          orderId: order.id,
          productName: product.name,
          productDescription: product.description,
          productImage: product.imageUrl || "default.png",
          quantity: product.OrderItem.quantity,
          totalPrice: product.OrderItem.quantity * product.price,
          orderDate: order.createdAt,
          deliveryDate: order.updatedAt, // or a proper deliveryDate field if you have one
          deliveryStatus: order.status,
          deliveryPersonName: order.DeliveryPerson ? order.DeliveryPerson.name : "Not Assigned",
          deliveryPersonContact: order.DeliveryPerson ? order.DeliveryPerson.contact : "N/A"
        });
      });
    });

    res.json({
      success: true,
      responseMessage: "Orders fetched successfully",
      orders: mappedOrders
    });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  registerUser,
  loginUser,
  // adminLogin,
  // deliveryPersonLogin,
  // registerDeliveryPerson,
  forgetPassword,
  getAllOrders,
  getOrderById,
  assignDelivery,
  getAllDeliveryPersons,
  placeOrder,
  getMyOrders
};
