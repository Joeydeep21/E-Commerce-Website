// file: controllers/categoryController.js

const { Category } = require('../config/db');

// Map DB Category -> frontend shape
const mapCategory = (category) => ({
  id: category.id,
  title: // if DB column is 'name' use that, otherwise try 'title'
    (category.name !== undefined ? category.name : category.title) || '',
  description:
    // if DB has description column use it, otherwise empty string
    (category.description !== undefined ? category.description : null),
  createdAt: category.createdAt,
  updatedAt: category.updatedAt
});

// Create Category (/api/category/add)
const createCategory = async (req, res, next) => {
  try {
    const { title, description } = req.body;

    if (!title || title.toString().trim() === '') {
      return res.status(400).json({
        success: false,
        responseMessage: 'Category title is required'
      });
    }

    const normalizedTitle = title.toString().trim();

    // Determine DB column name used for title (name or title)
    const titleColumn = (Category.rawAttributes && Category.rawAttributes.name) ? 'name'
                       : (Category.rawAttributes && Category.rawAttributes.title) ? 'title'
                       : 'name'; // fallback to 'name'

    // Build where clause dynamically
    const whereClause = {};
    whereClause[titleColumn] = normalizedTitle;

    // Check existing
    const existing = await Category.findOne({ where: whereClause });
    if (existing) {
      return res.status(400).json({
        success: false,
        responseMessage: 'Category already exists'
      });
    }

    // Build payload to create
    const payload = {};
    payload[titleColumn] = normalizedTitle;
    if (Category.rawAttributes && Category.rawAttributes.description) {
      payload.description = description || null;
    }

    const category = await Category.create(payload);

    res.json({
      success: true,
      responseMessage: 'Category created successfully',
      categories: [mapCategory(category)]
    });
  } catch (err) {
    next(err);
  }
};

// Get Categories (/api/category/all)
const getCategories = async (req, res, next) => {
  try {
    const categories = await Category.findAll({ order: [['createdAt', 'ASC']] });
    res.json({
      success: true,
      responseMessage: 'Categories fetched successfully',
      categories: categories.map(mapCategory)
    });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  createCategory,
  getCategories
};
