const { Order, Product, OrderProduct } = require('../config/db');

const placeOrder = async (req, res, next) => {
  try {
    const { userId, products } = req.body; // products = [{ productId, quantity, price }]
    let total = 0;
    products.forEach(p => { total += p.price * p.quantity; });
    const order = await Order.create({ UserId: userId, total, status: 'PENDING' });
    for (const p of products) {
      await OrderProduct.create({ OrderId: order.id, ProductId: p.productId, quantity: p.quantity, price: p.price });
    }
    res.json(order);
  } catch (err) {
    next(err);
  }
};

const getUserOrders = async (req, res, next) => {
  try {
    const { userId } = req.params;
    const orders = await Order.findAll({ where: { UserId: userId }, include: Product });
    res.json(orders);
  } catch (err) {
    next(err);
  }
};

module.exports = { placeOrder, getUserOrders };
