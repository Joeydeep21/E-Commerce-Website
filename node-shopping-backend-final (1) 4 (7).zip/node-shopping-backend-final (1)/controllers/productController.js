// controllers/productController.js
const path = require('path');
const fs = require('fs');
const { Product, Category } = require('../config/db');

const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(__dirname, '..', 'uploads');

// map DB -> frontend
const mapProduct = (product) => ({
  id: product.id,
  title: product.name,
  description: product.description,
  price: product.price,
  quantity: product.stock,
  imageName: product.imageUrl || 'default.png',
  category: product.Category ? {
    id: product.Category.id,
    title: product.Category.name
  } : null,
  createdAt: product.createdAt,
  updatedAt: product.updatedAt
});

// Add Product (/api/product/add)
// Accepts multipart/form-data with:
//   image (file), title, description, price, quantity, categoryId
const addProduct = async (req, res, next) => {
  try {
    // Multer stores file metadata on req.file
    // Form fields are on req.body (strings)
    const title = req.body.title || req.body.name || null;
    const description = req.body.description || null;
    const price = req.body.price ? parseFloat(req.body.price) : 0;
    const stock = req.body.quantity ? parseInt(req.body.quantity, 10) : (req.body.stock ? parseInt(req.body.stock, 10) : 0);
    const categoryId = req.body.categoryId ? parseInt(req.body.categoryId, 10) : null;

    // image handling
    let imageUrl = null;
    if (req.file && req.file.filename) {
      imageUrl = req.file.filename;
    }

    // validation (server-side)
    if (!title) {
      return res.status(400).json({ success: false, responseMessage: 'Product title is required' });
    }
    if (!categoryId) {
      return res.status(400).json({ success: false, responseMessage: 'categoryId is required' });
    }

    // ensure category exists
    const category = await Category.findByPk(categoryId);
    if (!category) {
      return res.status(404).json({ success: false, responseMessage: 'Category not found' });
    }

    // create product with DB columns: name, description, price, stock, CategoryId, imageUrl
    const created = await Product.create({
      name: title,
      description,
      price,
      stock,
      CategoryId: categoryId,
      imageUrl
    }).catch((err)=>{
      console.log("error came while saving product",err);
      
    })

    // re-fetch with Category included so response contains category info
    const productWithCategory = await Product.findByPk(created.id, { include: [Category] });
    console.log("created----",created);
    
    res.json({
      success: true,
      responseMessage: 'Product added successfully',
      products: [mapProduct(productWithCategory)]
    });
  } catch (err) {
    next(err);
  }
};

// GET /api/product/all
const getAllProducts = async (req, res, next) => {
  try {
    const products = await Product.findAll({ include: [Category], order: [['createdAt', 'DESC']] });
    res.json({
      success: true,
      responseMessage: 'Products fetched successfully',
      products: products.map(mapProduct)
    });
  } catch (err) {
    next(err);
  }
};

// GET /api/product/category?categoryId=...
const getProductsByCategory = async (req, res, next) => {
  try {
    const { categoryId } = req.query;
    if (!categoryId) {
      return res.status(400).json({ success: false, responseMessage: 'categoryId is required' });
    }
    const products = await Product.findAll({ where: { CategoryId: categoryId }, include: [Category], order: [['createdAt', 'DESC']] });
    res.json({
      success: true,
      responseMessage: 'Products fetched successfully',
      products: products.map(mapProduct)
    });
  } catch (err) {
    next(err);
  }
};

// GET /api/product/id?productId=...
const getProductById = async (req, res, next) => {
  try {
    const { productId } = req.query;
    if (!productId) {
      return res.status(400).json({ success: false, responseMessage: 'productId is required' });
    }
    const product = await Product.findByPk(productId, { include: [Category] });
    if (!product) {
      return res.status(404).json({ success: false, responseMessage: 'Product not found' });
    }
    res.json({
      success: true,
      responseMessage: 'Product fetched successfully',
      products: [mapProduct(product)]
    });
  } catch (err) {
    next(err);
  }
};

// Serve product image by filename
// GET /api/product/:filename
const serveImage = (req, res) => {
  try {
    const filename = req.params.filename;
    if (!filename) {
      return res.status(400).send('filename required');
    }
    const filePath = path.join(UPLOAD_DIR, filename);
    if (!fs.existsSync(filePath)) {
      return res.status(404).send('Image not found');
    }
    res.sendFile(filePath);
  } catch (err) {
    res.status(500).send('Server error');
  }
};

module.exports = {
  addProduct,
  getAllProducts,
  getProductsByCategory,
  getProductById,
  serveImage
};
