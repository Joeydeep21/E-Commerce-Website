const { Cart, Product, User, Category } = require('../config/db');

// ✅ Add to Cart (POST /api/user/cart/add)
console.log("api allledddpppp.....")
const addToCart = async (req, res, next) => {
  try {
    const { userId, productId, quantity } = req.body;
    console.log("body data------",userId, productId, quantity );
    

    if (!userId || !productId) {
      return res.status(400).json({
        success: false,
        responseMessage: "userId and productId are required"
      });
    }

    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        responseMessage: "User not found"
      });
    }

    const product = await Product.findByPk(productId, { include: [Category] });
    if (!product) {
      return res.status(404).json({
        success: false,
        responseMessage: "Product not found"
      });
    }

    let cart = await Cart.findOne({ where: { UserId: userId } });
    console.log("chota cart---",cart);
    
    if (!cart) {
      cart = await Cart.create({ UserId: userId });
    }
console.log("cart safe karne se phehle....",product);

    await cart.addProduct(product, { through: { quantity: quantity || 1 } });

console.log("cart save karne k badd....");

    res.json({
      success: true,
      responseMessage: "Product added to cart successfully"
    });
  } catch (err) {
    next(err);
  }
};

// ✅ Remove from Cart (GET /api/user/mycart/remove?cartId=...)
const removeFromCart = async (req, res, next) => {
  try {
    const { cartId } = req.query;

    if (!cartId) {
      return res.status(400).json({
        success: false,
        responseMessage: "cartId is required"
      });
    }

    const cart = await Cart.findByPk(cartId, { include: [Product] });
    if (!cart) {
      return res.status(404).json({
        success: false,
        responseMessage: "Cart not found"
      });
    }

    await cart.setProducts([]); // remove all products for this cartId

    res.json({
      success: true,
      responseMessage: "Product removed from cart successfully"
    });
  } catch (err) {
    next(err);
  }
};

// ✅ Get My Cart (GET /api/user/mycart?userId=...)
const getMyCart = async (req, res, next) => {
  try {
    const { userId } = req.query;

    if (!userId) {
      return res.status(400).json({
        success: false,
        responseMessage: "UserId is required"
      });
    }

    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        responseMessage: "User not found"
      });
    }

    const cart = await Cart.findOne({
      where: { UserId: userId },
      include: [{ model: Product, include: [Category] }]
    });

    if (!cart || cart.Products.length === 0) {
      return res.json({
        success: true,
        responseMessage: "Cart is empty",
        totalCartPrice: 0,
        cartData: []
      });
    }

    let totalCartPrice = 0;

    const mappedProducts = cart.Products.map(product => {
      const price = product.price;
      const quantity = product.CartItem.quantity;
      totalCartPrice += price * quantity;

      return {
        cartId: cart.id,                         // used in MyCart.jsx
        productName: product.name,
        productDescription: product.description,
        productImage: product.imageUrl || "default.png",
        quantity
      };
    });

    res.json({
      success: true,
      responseMessage: "Cart fetched successfully",
      totalCartPrice,
      cartData: mappedProducts
    });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  addToCart,
  removeFromCart,
  getMyCart
};
