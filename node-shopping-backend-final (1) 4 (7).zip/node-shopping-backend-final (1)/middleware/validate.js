function validate(schema) {
  return (req, res, next) => {
    console.log("request boydyyy",req.body)
    const { error } = schema.validate(req.body);
    if (error) {
      console.log("error came from validate schema",error);
      
      return res.status(400).json({ error: error.details[0].message });
    }
    next();
  };
}
module.exports = { validate };
