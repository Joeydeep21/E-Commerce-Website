# Node Shopping Backend

Converted from Spring Boot to Node.js (Express + Sequelize + MySQL).

## Setup Instructions

1. Clone or extract the project.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Configure database in `.env` (MySQL):
   ```env
   DB_HOST=localhost
   DB_USER=root
   DB_PASSWORD=root123
   DB_NAME=online_shopping
   ```
4. Run the project:
   ```bash
   npm start
   ```

## Features
- Sequelize ORM with MySQL (auto schema sync).
- DTO validation with Joi.
- Swagger API docs at `/api-docs`.
- Image uploads stored at:
  ```
  E:/Ecommerce Project - FullStack Project/images
  ```
- Seed data (admin user, categories, sample products).

## Default Admin
```
email: admin@gmail.com
password: admin123
```
